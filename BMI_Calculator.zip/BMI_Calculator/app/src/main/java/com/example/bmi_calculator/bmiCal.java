package com.example.bmi_calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class bmiCal extends AppCompatActivity {

    EditText Age, height, weight;
    TextView result;
    Button Calc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_cal);
//id dalam interface
        Age = (EditText) findViewById(R.id.AgeText);
        height = (EditText) findViewById(R.id.heightText);
        weight = (EditText) findViewById(R.id.WeightText);
        result = (TextView) findViewById(R.id.resultText);
        Calc = (Button) findViewById(R.id.Calc);

        Calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateBMI();
            }
        });
    }

    //calculate the bmi
    private void calculateBMI(){
        String heightSTR = height.getText().toString();
        String weightSTR = weight.getText().toString();


        if(heightSTR != null && !"".equals(heightSTR) && weightSTR != null && !"".equals(weightSTR)  ){

            float heightValue = Float.parseFloat(heightSTR)/100;
            float weightValue = Float.parseFloat(weightSTR);

            float bmi = weightValue/ (heightValue + heightValue);

            displayBMI(bmi);


        }
    }

    //to select bmi categories
    private void displayBMI(float bmi){
        String bmiLabel = "";

        if(Float.compare(bmi, 15f) <=0){

            bmiLabel = "Very severely underweight";
        }

        else if (Float.compare(bmi, 15f) > 0 && Float.compare(bmi, 16f) <=0 ){
            bmiLabel = "Severely underweight";
        }

        else if (Float.compare(bmi, 16f) > 0 && Float.compare(bmi, 18.5f) <=0 ){
            bmiLabel = "Underweight";
        }

        else if (Float.compare(bmi, 18.5f) > 0 && Float.compare(bmi, 25f) <=0 ){
            bmiLabel = "Normal";
        }

        else if (Float.compare(bmi, 25f) > 0 && Float.compare(bmi, 30f) <=0 ){
            bmiLabel = "Overweight";
        }

        else if (Float.compare(bmi, 30f) > 0 && Float.compare(bmi, 35f) <=0 ){
            bmiLabel = "Obese class I";
        }

        else if (Float.compare(bmi, 35f) > 0 && Float.compare(bmi, 40f) <=0 ){
            bmiLabel = "Obese class II";
        }

        else{
            bmiLabel = "Obese class III";
        }

        //display result
        bmiLabel = "Result: " + bmi + "\n" + bmiLabel;


        result.setText(bmiLabel);
    }
}
