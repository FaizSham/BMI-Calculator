package com.example.bmi_calculator;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private EditText Name, password;
    private Button Login;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //id cari interface
        Name = (EditText)findViewById(R.id.Name);
        password =(EditText)findViewById(R.id.password1);
        Login = (Button)findViewById(R.id.start1);

        firebaseAuth= FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);
        FirebaseUser user = firebaseAuth.getCurrentUser();

        //button login function
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(Name.getText().toString(), password.getText().toString());
            }
        });


        //if login fail will go to main page
        if(user != null){
            finish();
            startActivity(new Intent(MainActivity.this, bmiCal.class));
        }
    }

    //check password email firebase
    private void validate(String userName, String userPassword){

        //to show the progress dialog
        progressDialog.setMessage("Verification is in progress.. Please wait!");
        progressDialog.show();

        firebaseAuth.signInWithEmailAndPassword(userName,userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){
                    //to end the progress dialog
                    progressDialog.dismiss();

                    //make toast message to the user when it is successful
                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this, bmiCal.class));

                }else{
                    progressDialog.dismiss();

                    //push message failed if login unsuccessful login
                    Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();

                }
            }
        });

    }



    //button utk ke page register
    public void pageregister(View view)
    {
        Intent startNewActivity = new Intent(this, RegistrationActivity.class);
        startActivity(startNewActivity);
    }



}
